package lab.visitor;

public interface Visitable {
    void accept(Visitor v);
}

