package lab.visitor;

/**
 * Visitor for finding if the average number of extra hours for bosses is higher
 * than the one for employees.
 * <p>
 * Interns are not taken into consideration.
 */
class MostHardworkingEmployeeFinder implements Visitor {

    @Override
    public void visit(final Employee e) {
        //TODO
    }

    @Override
    public void visit(final Boss b) {
        //TODO
    }

    public boolean isBossHardWorking() {
        //TODO

        return false;
    }
}
