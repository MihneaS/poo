package lab.visitor;

import java.util.LinkedList;

public class Boss extends Employee {
    protected float bonus;

    public Boss(final String name, final float salary, final float newBonus) {
        super(name, salary);
        this.bonus = newBonus;
    }

    public Boss(final String name,
                final float salary,
                final float extraHours,
                final float newBonus) {
        super(name, salary, extraHours);
        this.bonus = newBonus;
    }

    public final float getBonus() {
        return bonus;
    }

    public final void setBonus(final float newBonus) {
        this.bonus = newBonus;
    }

    public final LinkedList<Visitable> getSubordinates() {
        //TODO
        return null;
    }

    public final void addSubordinate(final Visitable subordinate) {
        //TODO
    }

    //TODO ex1b - remove accept
    @Override
    public final void accept(final Visitor v) {
        v.visit(this);
    }
}
