package lab.visitor;

//TODO make Intern visitable
public final class Intern {

    private String name;
    private int duration;  // in months

    public String getName() {
        return name;
    }
}
