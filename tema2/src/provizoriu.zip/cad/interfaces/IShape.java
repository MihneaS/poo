package cad.interfaces;

import cad.fundamental.Canvas;

public interface IShape {
    void drawOn(Canvas canvas);
}
