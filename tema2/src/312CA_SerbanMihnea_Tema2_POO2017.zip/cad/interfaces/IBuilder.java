/*
 * POO - tema 2
 * SERBAN Mihnea
 * 321CA
 */

package cad.interfaces;

public interface IBuilder {
    IShape build(String[] args);
}
