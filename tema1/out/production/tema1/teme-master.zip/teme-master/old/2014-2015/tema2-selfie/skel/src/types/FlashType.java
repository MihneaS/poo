package types;

public enum FlashType {
	ON, OFF, AUTO
}
