Continutul arhivei:
  * config_files/ - configurarile retelelor din teste
  * images/ - imaginile folosite in teste
  * reference_files/ - fisierele de referinte pentru rezultate
  * stdin_files/ - contine fisierele cu comenzi
  * checker.sh - script-ul care testeaza tema
  * comparator.jar - compara 2 imagini

Copiati continutul arhivei in proiectul temei astfel incat directorul src sa se afle
pe acelasi nivel cu checker.sh.

Ex:

Tema2POO/
  |-- bin/
  |-- src/
  |-- config_files
  |-- images/ 
  |-- reference_files/ 
  |-- stdin_files/ 
  |-- checker.sh
  |-- comparator.jar

Pentru testare, rulati script-ul checker.sh!

