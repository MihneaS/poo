public enum TYPE {
	and, article, be, character, first_person, first_person_possessive, first_person_reflexive, negative_adjective, negative_comparative, negative_noun, neutral_adjective, neutral_noun, nothing, positive_adjective, positive_comparative, positive_noun, second_person, second_person_possessive, second_person_reflexive, third_person_possessive, math, keyword, speak, terminator, irelevant
}
