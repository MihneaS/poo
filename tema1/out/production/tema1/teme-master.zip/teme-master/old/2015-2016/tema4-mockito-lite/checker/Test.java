
public interface Test {

	boolean execute();
}
