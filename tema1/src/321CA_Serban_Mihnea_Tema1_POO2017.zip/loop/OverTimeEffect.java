/*
 * POO - tema1
 * SERBAN Mihnea
 * 321CA
 */

package loop;

interface OverTimeEffect {
    void applyTo(Hero hero);
}
